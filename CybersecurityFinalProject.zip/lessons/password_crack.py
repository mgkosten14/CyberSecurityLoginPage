""""
Password salting and hashing example
"""

import hashlib
import os  # << hint
import string
import random
import array

SPECIAL_CHAR = string.punctuation
DIGITS = string.digits
LOWERCASE = string.ascii_lowercase
UPPERCASE = string.ascii_uppercase

COMBINED_CHAR = SPECIAL_CHAR + DIGITS + LOWERCASE + UPPERCASE

PASSWORD_MIN_LENGTH = 8
PASSWORD_MAX_LENGTH = 25


def hash_pw(plain_text, salt='') -> str:
    """
    Generate hash of plain text. Here we allow for passing in a salt
    explicitly. This is so you can tinker and see the results.

    Python's Hashlib provides all we need here. Documentation is at
    https://docs.python.org/3/library/hashlib.html.

    Here we use SHA-1. (Weak!) For stronger encryption, see: bcrypt,
    scrypt, or Argon2. Nevertheless, this code should suffice for an
    introduction to some important concepts and practices.

    A few things to note.

    If we supply a fixed salt (or don't use a salt at all), then the
    output of the hash function becomes predictable -- for a given
    algorithm, the same password will always produce the same result.

    If we allow our algorithm to generate a salt from a pseudorandom
    input (e.g., using os.urandom(60)) then the same password will
    produce different results. All we know is the length of the combined
    salt and password.

    If we wish to be able to authenticate, then we must store the salt
    with the hash. We facilitate this by prepending the salt to the hash.

    :param plain_text: str (user-supplied password)
    :param salt: str
    :return: str (ASCII-encoded salt + hash)
    """

    salt = os.urandom(20).hex()
    hashable = salt + plain_text  # concatenate salt and plain_text
    hashable = hashable.encode('utf-8')  # convert to bytes
    this_hash = hashlib.sha1(hashable).hexdigest()  # hash w/ SHA-1 and hexdigest
    return salt + this_hash  # prepend hash and return


def authenticate(stored, plain_text, salt_length=None) -> bool:
    """
    Authenticate by comparing stored and new hashes.

    :param stored: str (salt + hash retrieved from database)
    :param plain_text: str (user-supplied password)
    :param salt_length: int
    :return: bool
    """
    salt_length = salt_length or 40  # set salt_length
    salt = stored[:salt_length]  # extract salt from stored value
    stored_hash = stored[salt_length:]  # extract hash from stored value
    hashable = salt + plain_text  # concatenate hash and plain text
    hashable = hashable.encode('utf-8')  # convert to bytes
    this_hash = hashlib.sha1(hashable).hexdigest()  # hash and digest
    return this_hash == stored_hash  # compare

def password_strength(test_password) -> bool:
    """
    Check basic password strength. Return true if password
    meets minimum complexity criteria, false otherwise.

    :param test_password: str
    :return: bool
    """
    if test_password.isalnum() or test_password.isalpha():
        return False
    if len(test_password) < PASSWORD_MIN_LENGTH:
        return False
    if len(test_password) > PASSWORD_MAX_LENGTH:
        return False
    special_char_check = False
    has_upper = False
    has_lower = False
    has_digit = False
    for ch in test_password:
        if ch in SPECIAL_CHAR:
            special_char_check = True
        if ch.isupper():
            has_upper = True
        if ch.islower():
            has_lower = True
        if ch.isdigit():
            has_digit = True
    if not special_char_check or \
            not has_upper or \
            not has_lower or \
            not has_digit:
        return False
    else:
        return True

def password_generator():
    """This generates a strong random password for a user
        25 characters, with at least one of each of the following
        digit, uppercase, lowercase, and special character
        SITE https://www.geeksforgeeks.org/generating-strong-password-using-python/"""
    rand_digit = random.choice(DIGITS)
    rand_upper = random.choice(UPPERCASE)
    rand_lower = random.choice(LOWERCASE)
    rand_symbol = random.choice(SPECIAL_CHAR)

    # create temp pass so at least one of each character above
    temp_pass = rand_digit + rand_upper + rand_lower + rand_symbol

    # now know have 1 char of each set of chars, fill rest randomly
    for i in range(PASSWORD_MAX_LENGTH - len(temp_pass)):
        temp_pass += random.choice(COMBINED_CHAR)

    # convert to array to shuffle so not have consistant pattern at beginning
    temp_pass_list = array.array('u', temp_pass)
    random.shuffle(temp_pass_list)

    # traverse array and append to form password
    password = ""
    for x in temp_pass_list:
        password += x
    
    return password